#include <iostream>
#include <string>

using namespace std;

int main() {
  // Create a list of USSD codes and their descriptions.
  const string ussdCodes[] = {
    "*100#", "Balance inquiry",
    "*101#", "Data plan activation",
    "*102#", "Account recharge",
    "*103#", "Transaction history",
    "*104#", "Profile viewing",
    "*105#", "Customer support access",
    "*106#", "Language selection",
    "*107#", "Clean exit"
  };

  // Print the main menu.
  cout << "USSD System Mini Console Application" << endl;
  for (int i = 0; i < sizeof(ussdCodes) / sizeof(ussdCodes[0]); i++) {
    cout << i + 1 << ". " << ussdCodes[i] << endl;
  }

  // Get the user's input.
  int ussdCode;
  cout << "Enter a USSD code: ";
  cin >> ussdCode;

  // Validate the user's input.
  if (ussdCode < 1 || ussdCode > sizeof(ussdCodes) / sizeof(ussdCodes[0])) {
    cout << "Invalid USSD code." << endl;
    return 1;
  }

  // Execute the corresponding functionality.
  switch (ussdCode) {
    case 1: // Balance inquiry
      cout << "Your account balance is $100." << endl;
      break;
    case 2: // Data plan activation
      cout << "Your data plan has been activated." << endl;
      break;
    case 3: // Account recharge
      cout << "Your account has been recharged with $50." << endl;
      break;
    case 4: // Transaction history
      cout << "Your transaction history is as follows:" << endl;
      cout << "- 2023-08-16: $100 recharge" << endl;
      cout << "- 2023-08-15: Data plan activation" << endl;
      break;
    case 5: // Profile viewing
      cout << "Your profile information is as follows:" << endl;
      cout << "- Name: John Doe" << endl;
      cout << "- Phone number: +1234567890" << endl;
      cout << "- Email address: john.doe@example.com" << endl;
      break;
    case 6: // Customer support access
      cout << "You have been connected to customer support." << endl;
      break;
    case 7: // Language selection
      cout << "Select a language: 1. English, 2. Spanish, 3. French" << endl;
      cin >> ussdCode;
      if (ussdCode == 1) {
        cout << "The language has been set to English." << endl;
      } else if (ussdCode == 2) {
        cout << "The language has been set to Spanish." << endl;
      } else if (ussdCode == 3) {
        cout << "The language has been set to French." << endl;
      }
      break;
    case 8: // Clean exit
      cout << "Exiting..." << endl;
      return 0;
  }

  return 0;
}
